[signal,f_echantillonnage] = audioread('Audio/007.wav');
sound(signal,f_echantillonnage);

save musique;